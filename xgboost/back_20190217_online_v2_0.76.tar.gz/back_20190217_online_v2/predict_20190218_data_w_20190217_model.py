#!/bin/python

import numpy as np
import xgboost as xgb;
import pandas as pd;
from xgboost import XGBClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn import metrics
from sklearn import cross_validation, metrics
from sklearn.preprocessing import LabelEncoder
from config import *
from time import time
from datetime import  datetime

DATA_PATH= '/root/davidwwang/kge_rec/dataset/follow_rec/20190218/'

columns = ('ftime,'
'label,'
'uid,'
'touid,'
'ugcid,'
'ppr,'
'comm_friend_count,'
'bind_commNum,'
'exposureNum,'
'clickNum,'
'clickRatio,'
'timeInterval,'
'age,'
'fjifen,'
'fans_num,'
'follow_num,'
'all_login_dacs,'
'pagerank,'
'publish_day,'
'z_fjifen,'
'z_fans_num,'
'z_follow_num,'
'z_pagerank,'
'z_publish_sum_dacs,'
'z_publish_day,'
'z_publish_dacs,'
'z_show_gift_list_num,'
'z_detail_num,'
'z_detail_users,'
'z_share_ratio,'
'z_gift_ratio,'
'z_show_gift_list_ratio,'
'z_play_ratio,'
'z_detail_ratio'
)

drop_col = []
drop_col = ('ftime,uid,touid,ugcid').split(',')

def read_data(input_file):
    global columns

    chunksize = 1000000       # perhaps try some different values here?
    chunks = pd.read_csv(input_file, delimiter=',', header=0, chunksize=chunksize) 

    data = pd.concat( [ chunk.to_sparse(fill_value=0.0) for chunk in chunks ] )

    data.columns = columns.split(',')
    data = data.drop(drop_col, axis=1)
    columns = ','.join(data.columns)
    print("type(data): ",type(data))

    test_x = data.drop(['label'], axis=1).values
    test_y = data.label.values.to_dense()

    print("test_x:",type(test_x), " test_y:", type(test_y));
    return  test_x, test_y

def main():
  test_file = '20190218_test_80w.csv'
  X, y= read_data(os.path.join(DATA_PATH, test_file))
  
  booster = xgb.Booster()
  booster.load_model('20190217_model.bin')

  xgb1 = XGBClassifier()
  xgb1._Booster = booster
  xgb1._le = LabelEncoder().fit(y)

  print(xgb1)

  dtest_predictions = xgb1.predict(X)
  dtest_predprob = xgb1.predict_proba(X)[:,1]

  #Print model report:
  print("\nModel Report(test)")
  print("Accuracy : %.4g" % metrics.accuracy_score(y, dtest_predictions))
  print("AUC Score (test): %f" % metrics.roc_auc_score(y, dtest_predprob))
 


if __name__ == "__main__":
  main()
