#!/bin/python

import os
import numpy as np
import xgboost as xgb;
import pandas as pd;
from xgboost import XGBClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn import metrics
from sklearn import cross_validation, metrics
from time import time
from datetime import  datetime

columns = ('ftime,'
'label,'
'uid,'
'touid,'
'ugcid,'
'ppr,'
'comm_friend_count,'
'bind_commNum,'
'exposureNum,'
'clickNum,'
'clickRatio,'
'timeInterval,'
'age,'
'fjifen,'
'fans_num,'
'follow_num,'
'all_login_dacs,'
'pagerank,'
'publish_day,'
'z_fjifen,'
'z_fans_num,'
'z_follow_num,'
'z_pagerank,'
'z_publish_sum_dacs,'
'z_publish_day,'
'z_publish_dacs,'
'z_show_gift_list_num,'
'z_detail_num,'
'z_detail_users,'
'z_share_ratio,'
'z_gift_ratio,'
'z_show_gift_list_ratio,'
'z_play_ratio,'
'z_detail_ratio'
)

drop_col = []
drop_col = ('ftime,uid,touid,ugcid').split(',')

def read_data(input_file):
    global columns

    chunksize = 1000000       # perhaps try some different values here?
    chunks = pd.read_csv(input_file, delimiter=',', header=0, chunksize=chunksize) 

    data = pd.concat( [ chunk.to_sparse(fill_value=0.0) for chunk in chunks ] )

    data.columns = columns.split(',')
    data = data.drop(drop_col, axis=1)
    columns = ','.join(data.columns)
    print("type(data): ",type(data))

    train_xy, test_xy = train_test_split(data, test_size=0.3, random_state=1)
    print("type(train_xy): ",type(train_xy))
    train_x = train_xy.drop(['label'], axis=1).values
    train_y = train_xy.label.values.to_dense()
    test_x = test_xy.drop(['label'], axis=1).values
    test_y = test_xy.label.values.to_dense()

    print("train_x:",type(train_x), " train_y:", type(train_y));
    return train_x, train_y, test_x, test_y

def modelfit(alg, dtrain, dlabel, x_test, y_test, useTrainCV=True, cv_folds=5, early_stopping_rounds=50):
    
    if useTrainCV:
        xgb_param = alg.get_xgb_params()
        xgtrain = xgb.DMatrix(dtrain, label=dlabel)
        cvresult = xgb.cv(xgb_param, xgtrain, num_boost_round=alg.get_params()['n_estimators'], nfold=cv_folds,
            metrics='auc', early_stopping_rounds=early_stopping_rounds)
        alg.set_params(n_estimators=cvresult.shape[0])
    
    #Fit the algorithm on the data
    alg.fit(dtrain, dlabel,eval_metric='auc')
        
    #Predict training set:
    dtrain_predictions = alg.predict(dtrain)
    dtrain_predprob = alg.predict_proba(dtrain)[:,1]
    
    #Predict test set:
    dtest_predictions = alg.predict(x_test)
    dtest_predprob = alg.predict_proba(x_test)[:,1]
    
    #Print model report:
    print("\nModel Report(train)")
    print("Accuracy : %.4g" % metrics.accuracy_score(dlabel, dtrain_predictions))
    print("AUC Score (Train): %f" % metrics.roc_auc_score(dlabel, dtrain_predprob))
    
    #Print model report:
    print("\nModel Report(test)")
    print("Accuracy : %.4g" % metrics.accuracy_score(y_test, dtest_predictions))
    print("AUC Score (test): %f" % metrics.roc_auc_score(y_test, dtest_predprob))
                    
    feat_imp = pd.Series(alg.feature_importances_).sort_values(ascending=False)
    print(feat_imp[:50])
#    feat_imp.plot(kind='bar', title='Feature Importances')
#    plt.ylabel('Feature Importance Score')






def main():
  DATA_PATH='/root/davidwwang/kge_rec/dataset/follow_rec/20190217/'  
  train_file = '20190217_333w_train.csv'
  train_x, train_y, test_x, test_y = read_data(os.path.join(DATA_PATH, train_file))
  X_train = train_x
  X_test = test_x
  y_train = train_y
  y_test = test_y


  xgb1 = XGBClassifier(
   learning_rate = 0.1,
   n_estimators=200,
   max_depth=2,
   min_child_weight=15.0,
   gamma=1.0,
   subsample=0.7,
   colsample_bytree=0.7,
   objective= 'binary:logistic',
   n_jobs=50,
   #scale_pos_weight=1,
   random_state=19910825,
   reg_lambda = 2,
   reg_alpha = 2,
   eval_metric="auc")

  modelfit(xgb1, X_train, y_train, X_test, y_test, useTrainCV=False)
  print(xgb1)

  xgb.Booster.save_model(xgb1.get_booster(), fname="20190217_model.bin")


if __name__ == "__main__":
  main()
