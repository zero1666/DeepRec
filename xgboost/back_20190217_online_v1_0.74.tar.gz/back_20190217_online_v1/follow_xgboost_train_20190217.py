#!/bin/python

import numpy as np
import xgboost as xgb
import pandas as pd
from xgboost import XGBClassifier
from sklearn.model_selection import train_test_split
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import accuracy_score
from sklearn import metrics
from sklearn import model_selection
from config import *
from time import time
from datetime import  datetime
from scipy import sparse  


columns = ('ftime,'
'label,'
'uid,'
'touid,'
'ugcid,'
'ppr,'
'comm_friend_count,'
'bind_commNum,'
'exposureNum,'
'clickNum,'
'clickRatio,'
'timeInterval,'
'age,'
'fjifen,'
'fans_num,'
'follow_num,'
'all_login_dacs,'
'pagerank,'
'publish_day,'
'z_fjifen,'
'z_fans_num,'
'z_follow_num,'
'z_pagerank,'
'z_publish_sum_dacs,'
'z_publish_day,'
'z_publish_dacs,'
'z_show_gift_list_num,'
'z_detail_num,'
'z_detail_users,'
'z_share_ratio,'
'z_gift_ratio,'
'z_show_gift_list_ratio,'
'z_play_ratio,'
'z_detail_ratio'
)

drop_col = []
drop_col = ('ftime,uid,touid,ugcid').split(',')

def read_data(input_file):
    global columns

    chunksize = 1000000       # perhaps try some different values here?
    chunks = pd.read_csv(input_file, delimiter=',', header=0, chunksize=chunksize) 

    data = pd.concat( [ chunk.to_sparse(fill_value=0.0) for chunk in chunks ] )

    data.columns = columns.split(',')
    data = data.drop(drop_col, axis=1)
    columns = ','.join(data.columns)
    print("type(data): ",type(data))

    train_xy, test_xy = train_test_split(data, test_size=0.3, random_state=1)
    print("type(train_xy): ",type(train_xy))
    train_x = train_xy.drop(['label'], axis=1).values
    train_y = train_xy.label.values.to_dense()
    test_x = test_xy.drop(['label'], axis=1).values
    test_y = test_xy.label.values.to_dense()

    print("train_x:",type(train_x), " train_y:", type(train_y));
    return train_x, train_y, test_x, test_y



def save_feature_importance(model, filename):
    global columns
    feat_imp = pd.Series(model.feature_importances_).sort_values(ascending=False)
    with open(filename, 'w') as f:
        for idx, x in zip(feat_imp.index, feat_imp):
            f.write(columns.split(',')[1:][idx] + '->' + str(x) + '\n')

def save_model(model, model_filename):
    if os.path.exists(model_filename):
        os.remove(model_filename)
    xgb.Booster.save_model(model, fname=model_filename)

def main():

    DATA_PATH='/root/davidwwang/kge_rec/dataset/follow_rec/20190217/'  
    train_file = '20190217_333w_train.csv'
    train_x, train_y, test_x, test_y = read_data(os.path.join(DATA_PATH, train_file))
    dtrain = xgb.DMatrix(train_x, label=train_y)
    dtest = xgb.DMatrix(test_x, label=test_y )
    watchlist = [(dtest, 'eval'), (dtrain, 'train')]
    params ={
        'learning_rate' : 0.02,
        'n_estimators': 100,
        'max_depth': 6,
        'min_child_weight': 2,
        'gamma':0.0,
        'subsample':0.6,
        'colsample_bytree': 0.6,
        'colsample_bylevel': 0.6,
        'objective':'binary:logistic',
        'n_jobs': 10,
        'scale_pos_weight':1,
        'random_state':1008,
        'reg_lambda':0.02,
        'eval_metric':"auc",
        'eta': 1,
        'silent':1,
    }
    watch_result ={} 
    model = xgb.train(params, dtrain, num_boost_round=10, evals = watchlist, evals_result = watch_result)

    print("\nModel Report(train)")
    print(watch_result)
    preds = model.predict(dtest)
    labels = dtest.get_label()
    print('error=%f' % (sum(1 for i in range(len(preds)) if int(preds[i] > 0.5) != labels[i]) / float(len(preds))))

    # print result
    print("\nModel Report(train)")
    save_model(model, os.path.join(MODEL_PATH, 'model.bin'))

if __name__ == "__main__":
    main()
