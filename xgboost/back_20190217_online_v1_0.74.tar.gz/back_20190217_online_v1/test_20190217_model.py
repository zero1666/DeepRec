#!/bin/python

import numpy as np
import xgboost as xgb;
import pandas as pd;
from xgboost import XGBClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn import metrics
from sklearn import cross_validation, metrics
from sklearn.preprocessing import LabelEncoder

def main():

  print(xgb.__version__)
  test_x = np.zeros([1,29])
  #test_x = np.array([[0.0,0,0,0,0,0.0,16385,32.0,114240.0,59.0,14.0,832.0,11.475952,1.0,1376377.0,402.0,38.0,24.780737,879.0,30.0,94.0,17.0,29.0,17.0,0.0,0.011904762,0.023809524,0.031746034,0.071428575],[0.0,0.0,0.0,0.0,0.0,0.0,1618899.0,30.0,6043.0,191.0,81.0,37.0,10.26988813,0.0,1369941.0,13689.0,333.0,114.225,290.0,1.0,1.0,0.0,8.0,6.0,0.0,0.0,0.0,0.0,0.0],[1.000,1,16,1,1,1.000,231456,37.000,7437.000,68.000,35.000,6.000,10.356,1.000,20349.000,80.000,50.000,10.929,51.000,1.000,1.000,1.000,2.000,2.000,0.100,0.100,0.100,0.100,0.100]] , dtype=float)
  test_x = np.array([[0.0,0.0,0.0,0.0,0.0,0.0,1684369.0,30.0,6043.0,191.0,81.0,31.0,10.26988813,0.0,1369941.0,13688.0,333.0,114.225,290.0,1.0,1.0,0.0,8.0,6.0,0.0,0.0,0.0,0.0,0.0]], dtype=float)
  print('test_x type',type(test_x),'shape', test_x.shape )
  
  booster = xgb.Booster()
  booster.load_model('./model/model.bin')

  xgb1 = XGBClassifier()
  xgb1._Booster = booster

  dtest_predprob = xgb1.predict_proba(test_x)

  print(dtest_predprob)
 


if __name__ == "__main__":
  main()
